<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">

   
    <style>
      #ques{
        min-height: 833px;
      }

    </style>
    

    <title> welcome to  iDiscuss - coding Forum</title>
  </head>
  <body>
    <?php include 'partials/_dbconnect.php'; ?>
    <?php include 'partials/_header.php'; ?>
    <!-- Slider starts here -->
     <div id="carouselExampleCaptions" class="carousel slide carousel-fade" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img/img2.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h2>Welcome to iDiscuss</h2>
                    <p>Technology News, Development and Trends</p>
                    <button class="btn btn-danger">Technology</button>
                    <button class="btn btn-primary">Web Development</button>
                    <button class="btn btn-success">Tech Fun</button>
                </div>
            </div>
            <div class="carousel-item">
                <img src="img/img1.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h2>The Best Coding Forum</h2>
                    <p>Technology News, Development and Trends</p>
                    <button class="btn btn-danger">Technology</button>
                    <button class="btn btn-primary">Web Development</button>
                    <button class="btn btn-success">Tech Fun</button>
                </div>
            </div>
            <div class="carousel-item">
                <img src="img/img3.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h2>Award winning Forum</h2>
                    <p>Technology News, Development and Trends</p>
                    <button class="btn btn-danger">Technology</button>
                    <button class="btn btn-primary">Web Development</button>
                    <button class="btn btn-success">Tech Fun</button>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    
    <?php
    
    $id = $_GET['threadid'];  
    $sql = "SELECT * FROM `threads` WHERE thread_id=$id";
    $result = mysqli_query($conn,$sql);
    while ($row =mysqli_fetch_assoc($result)) { 
      $title = $row['thread_title'];
      $desc = $row['thread_desc'];
      $thread_user_id=$row['thread_user_id'];

      // query the users table to find out the name of op
      $sql2= "SELECT user_email FROM `users` WHERE srno='$thread_user_id'";
      $result2 = mysqli_query($conn,$sql2);
      $row2=mysqli_fetch_assoc($result2);
      $posted_by=$row2['user_email'];    

    }


    ?>

<?php
$showAlert = false;
$method = $_SERVER['REQUEST_METHOD'];
if ($method=='POST') {
  //Insert thread into db
  $comment = $_POST['comment'];
  $comment=str_replace('<', '&lt;',$comment);
  $comment=str_replace('>','&gt;',$comment);
  $srno=$_POST['srno'];
  $sql = "INSERT INTO `comments` (`comment_content`, `thread_id`, `comment_time`, `comment_by`) VALUES ('$comment', '$id',current_timestamp(),'$srno')";
  $result = mysqli_query($conn,$sql);
  $showAlert = true;
  if ($showAlert) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success!</strong> Your comment has been added successfully| Please wait for community to respond.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
  }
}

?>

<!-- Category container starts here -->
    <div class="container my-4">
      <div class="jumbotron">
          <h1 class="display-4"><?php echo $title; ?> </h1>
          <p class="lead"><?php echo $desc; ?></p>
          <hr class="my-4">
          <p>This is peer to peer forum.
          No Spam / Advertising / Self-promote in the forums. ...
          Do not post copyright-infringing material. ...
          Do not post “offensive” posts, links or images. ...
          Do not cross post questions. ...
          Do not PM users asking for help. ...
          Remain respectful of other members at all times.
</p>
         <p class="text-left">Posted by:<em></b><?php echo $posted_by;?></b></em></p> 


</div>
</div>
<?php
if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){
echo '
<div class="container">
  <p>
  <button class="btn btn-warning" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
    <b>Post a Comment</b>
  </button>
</p>
<div class="collapse" id="collapseExample">
  <div class="card card-body">
   <form action="'.$_SERVER['REQUEST_URI']. '" method="post">
 
          <div class="form-group">
            <label for="desc">Type Your Comment</label>
            <textarea class="form-control" id="comment" name="comment" rows="3"></textarea>
            <input type="hidden" name="srno" value="'.$_SESSION['srno'].'">
          </div>
          <button type="submit" class="btn btn-warning">Post a Comment</button>
        </form>
  </div>
</div>
</div>';
}
else{
  echo '
  <div class="container"> 
  <p>
  <button class="btn btn-warning" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
    <h5>Post a Comment</h5>
  </button>
</p>

<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <h6 class="breadcrumb-item active my-2" aria-current="page">You are not logged in Please login to be able to post a comments </h6>
  </ol>
</nav>
</div>';
}
?>

<div class="container mb-5" id="ques">
  <h1 class="py-2">Discussion</h1>
<?php
    
    $id = $_GET['threadid'];  
    $sql = "SELECT * FROM `comments` WHERE thread_id=$id";
    $result = mysqli_query($conn,$sql);
    $noResult = true;
    while ($row =mysqli_fetch_assoc($result)) { 
    $noResult = false;
    $id = $row['comment_id'];
    $content = $row['comment_content'];
    $comment_time=$row['comment_time'];
    $thread_user_id = $row['comment_by'];
    $sql2= "SELECT user_email FROM `users` WHERE srno='$thread_user_id'";
    $result2 = mysqli_query($conn,$sql2);
    $row2=mysqli_fetch_assoc($result2);
     

    
    echo '
    <div class="media my-4">
  <img src="img/default user.png" class="mr-3" width ="34px" alt="">
  <div class="media-body">
     <p class="font-weight-bold my-0">'.$row2['user_email'].' '. $comment_time .'</p>
    '. $content .'
</div>
</div>';
}

//echo var_dump($noResult);
if ($noResult) {
  echo '<div class="jumbotron jumbotron-fluid">
  <div class="container">
      <p class="lead"><b> Be the first person to comment</b></p>
  <p class="display-4">No Comments Found.</p>
  </div>
</div>';
}
?>



  
</div>


      <!-- Use for loop to iterate  -->
           
     <?php include 'partials/_footer.php' ; ?> 
  
  


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js" integrity="sha384-VHvPCCyXqtD5DqJeNxl2dtTyhF78xXNXdkwX1CZeRusQfRKp+tA7hAShOK/B/fQ2" crossorigin="anonymous"></script>
    -->
  </body>
</html>