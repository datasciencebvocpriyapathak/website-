<?php
$showError = "false";
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include '_dbconnect.php';
    $email = $_POST['loginEmail'];
    $pass = $_POST['loginPass'];

    $sql = "Select * from users where user_email='$email'";
    $result = mysqli_query($conn, $sql);
    $numRows = mysqli_num_rows($result);
    if($numRows==1){
        $row = mysqli_fetch_assoc($result);
        if(password_verify($pass, $row['user_password'])){
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION['srno'] = $row['srno'];
            $_SESSION['useremail'] = $email;
            echo "logged in". $email;
        } 
        header("Location: /website@/index.php");  
    }
    //header("Location: /website@/index.php");  
}

?>