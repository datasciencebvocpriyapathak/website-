<div class="container-fluid  bg-dark text-light">
<p class="text-center py-3 mb-0">Copyright iDiscuss Coding Forums  2022 | All rights reserved </p>

</div>